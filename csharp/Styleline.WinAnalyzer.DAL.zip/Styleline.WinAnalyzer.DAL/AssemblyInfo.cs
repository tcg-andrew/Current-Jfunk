﻿// Assembly Styleline.WinAnalyzer.DAL, Version 1.0.0.0

[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2009")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Runtime.InteropServices.Guid("7581938a-d1ca-4c28-adeb-b669b930e092")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyProduct("Styleline.WinAnalyzer.DAL")]
[assembly: System.Reflection.AssemblyTitle("Styleline.WinAnalyzer.DAL")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCompany("")]

