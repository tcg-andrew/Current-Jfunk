﻿// Assembly Styleline.WinAnalyzer.CommPipe, Version 1.0.0.0

[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Reflection.AssemblyTitle("Styleline.WinAnalyzer.CommPipe")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Runtime.InteropServices.Guid("a03f657c-bf38-423e-8e5b-e8f91e73c0d8")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyProduct("Styleline.WinAnalyzer.CommPipe")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2009")]
[assembly: System.Reflection.AssemblyTrademark("")]

