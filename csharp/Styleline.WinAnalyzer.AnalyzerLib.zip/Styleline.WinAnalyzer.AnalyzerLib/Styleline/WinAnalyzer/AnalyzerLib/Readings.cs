﻿namespace Styleline.WinAnalyzer.AnalyzerLib
{
    using System;

    public enum Readings
    {
        Hertz,
        Watts,
        Volts,
        Amps,
        Ohms,
        PF,
        STATUS
    }
}

