﻿namespace Styleline.WinAnalyzer.AnalyzerLib
{
    using System;

    public enum RunState
    {
        Started = 1,
        Stopped = 2
    }
}

