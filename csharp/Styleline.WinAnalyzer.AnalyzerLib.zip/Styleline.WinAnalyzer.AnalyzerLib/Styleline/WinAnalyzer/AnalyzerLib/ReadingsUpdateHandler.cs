﻿namespace Styleline.WinAnalyzer.AnalyzerLib
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ReadingsUpdateHandler(decimal[] readings);
}

