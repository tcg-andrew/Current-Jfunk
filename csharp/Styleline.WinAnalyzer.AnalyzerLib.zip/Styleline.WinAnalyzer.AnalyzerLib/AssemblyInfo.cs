﻿// Assembly Styleline.WinAnalyzer.AnalyzerLib, Version 1.0.0.0

[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2009")]
[assembly: System.Reflection.AssemblyTitle("Styleline.WinAnalyzer.AnalyzerLib")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Reflection.AssemblyProduct("Styleline.WinAnalyzer.AnalyzerLib")]
[assembly: System.Runtime.InteropServices.Guid("647807e1-2daf-4a6d-8bd9-216d0803d049")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]

