﻿#region Usings

using Epicor.Mfg.BO;
using Epicor.Mfg.Core;
using System;

#endregion

namespace ObjectLibrary
{
    public class QuoteAssemblyInterface : EpicorExtension<QuoteAsm>
    {
        #region Public Methods

        #region Create Methods

        public void CreateQuoteAsm(string server, string port, string username, string password, int quotenum, int linenum, string partnum, string revision)
        {
            try
            {
                OpenSession(server, port, username, password, Session.LicenseType.Default);

                string outstr;
                BusinessObject.GetDetails(quotenum, linenum, 0, "Method", 0, 0, "", 0, partnum, revision, "", false, false, out outstr);
            }
            catch (Exception ex)
            {
                throw new Exception("CreateQuoteAsm (" + quotenum + ") (" + linenum + ") - " + ex.Message);
            }
            finally
            {
                CloseSession();
            }
        }

        #endregion

        #endregion
    }
}
