﻿namespace Styleline.WinAnalyzer.WinClient
{
    using System;
    using System.Runtime.CompilerServices;

    public class UlLabelTO
    {
        public string Description { get; set; }

        public string HeaterAmps { get; set; }

        public string JobNumber { get; set; }

        public string LightAmps { get; set; }
    }
}

