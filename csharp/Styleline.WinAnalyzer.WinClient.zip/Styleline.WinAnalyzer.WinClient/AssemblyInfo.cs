﻿// Assembly Styleline.WinAnalyzer.WinClient, Version 1.0.3673.42455

//[assembly: System.Runtime.CompilerServices.Extension]
[assembly: System.Reflection.AssemblyCompany("")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyTitle("Styleline.WinAnalyzer.WinClient")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyProduct("Styleline.WinAnalyzer.WinClient")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9  2009")]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.InteropServices.Guid("b59626d5-b5ac-456a-9d44-78d9bb5b53ba")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]

